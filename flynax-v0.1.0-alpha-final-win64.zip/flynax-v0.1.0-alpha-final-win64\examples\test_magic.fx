import "web"

main():
    print("Testing Magic Imports for Web...")
    # This function is injected via Magic Imports
    # We don't call it here to avoid runtime linking errors without the server,
    # but we verify it compiles.
    let server = flynax_server_init(8080)
    print("Success: flynax_server_init was recognized!")
