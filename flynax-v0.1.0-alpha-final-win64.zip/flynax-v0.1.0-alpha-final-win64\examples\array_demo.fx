# Array literals demonstration in Flynax

main:
    print("Array literals demo")
    
    # Simple integer array
    let numbers = [1, 2, 3, 4, 5]
    print("Created integer array")
    
    # Mixed type array (demonstrating syntax)
    let mixed = [1, 2, 3]  # Currently only processes elements
    print("Created mixed array")
    
    # Empty array
    let empty = []
    print("Created empty array")
    
    # Array in try-catch
    try:
        let data = [10, 20, 30]
        print("Array in try block created")
        
    catch(Error):
        print("Error with array creation")
    
    print("Array demo completed")