# Simple file test with strings (when ready)

main:
    # For now, test with integers
    let int x = 42
    print(x)
    
    # Future: File I/O with strings
    # let string content = "Hello, Flynax!"
    # file_write("test.txt", content)
    # let string read = file_read("test.txt")
    # print(read)
