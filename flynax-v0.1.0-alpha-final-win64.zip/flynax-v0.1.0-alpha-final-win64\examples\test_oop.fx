class User:
    let string name
    let int age
    
    set_data(string n, int a):
        this.name = n
        this.age = a
        
    print_info():
        print("User: ")
        print(this.name)
        print("Age: ")
        print(this.age)

main:
    print("OOP Test starting...")
    let user = User()
    user.set_data("Antigravity", 1)
    user.print_info()
    
    print("Direct field access:")
    user.age = 42
    print(user.age)
