module Math:
    add(int a, int b): int
        return a + b

    let pi = 314
