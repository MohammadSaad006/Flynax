# Test JSON Builder

main:
    # Create new JSON object
    let int obj = json_new()
    
    # Add fields
    json_add_str(obj, "message", "Hello JSON!")
    json_add_int(obj, "count", 42)
    json_add_str(obj, "status", "success")
    
    # Dump to string
    let string json_str = json_dump(obj)
    
    print("Generated JSON:")
    print(json_str)
