# Quick Stdlib Test - Essential Functions Only
# Minimal test to verify core functionality

main:
    print("=== Quick Stdlib Test ===")
    
    # Arrays
    print("\n[Arrays]")
    let arr =array_new()
    array_push(arr, 42)
    print("Pushed 42, length:")
    print(array_length(arr))
    print("Get value:")
    print(array_get(arr, 0))
    array_free(arr)
    
    # Strings
    print("\n[Strings]")
    let combined = string_concat("Hello", " World")
    print(combined)
    print("Length:")
    print(string_length(combined))
    
    # Math
    print("\n[Math]")
    print("Pi:")
    print(math_pi())
    print("Sqrt(25):")
    print(math_sqrt(25.0))
    print("Random 1-10:")
    print(math_random(1, 10))
    
    print("\n=== Test Complete ===")
