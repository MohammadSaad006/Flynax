# Quick Start Guide - Building Flynax

## ✅ Step 1: LLVM Installed!

LLVM 21.1.7 is now installed. **Restart your PowerShell terminal** to activate it.

---

## 📋 Step 2: Install Visual Studio (C++ Compiler)

You need a C++ compiler to build Flynax. Choose one:

### Option A: Visual Studio Community (Recommended)

**Install using winget:**
```powershell
winget install Microsoft.VisualStudio.2022.Community --override "--add Microsoft.VisualStudio.Workload.NativeDesktop --includeRecommended --quiet"
```

**Or download manually:**
1. Visit: https://visualstudio.microsoft.com/downloads/
2. Download "Visual Studio Community 2022" (free)
3. Run installer, select "Desktop development with C++"
4. Click Install (~5-10 minutes)

### Option B: Use Clang (from LLVM)

Since you have LLVM, you can use `clang` as your compiler!

**After restarting terminal:**
```powershell
clang++ -std=c++17 -Iinclude src\*.cpp -o flynax.exe
```

---

## 🚀 Step 3: Build Flynax

### Using Visual Studio:
1. Open **"Developer Command Prompt for VS 2022"** from Start Menu
2. Navigate: `cd e:\flynex`
3. Build: `.\build.bat`

### Using Clang:
```powershell
# Close and reopen PowerShell first!
cd e:\flynex
clang++ -std=c++17 -Iinclude src\main.cpp src\lexer.cpp src\parser.cpp src\ast.cpp src\codegen.cpp -o flynax.exe
```

---

## 🧪 Step 4: Test Flynax

```powershell
.\flynax.exe examples\hello.fx
```

**Expected output:**
```
Flynax Compiler v0.1.0
======================

[1] Lexical Analysis...
=== TOKENS ===
...
[2] Parsing...
✓ Parsing successful!
[3] Code Generation...
✓ IR written to: examples\hello.ll
```

---

## Next Steps

Once Flynax compiles successfully, we'll integrate real LLVM code generation to compile `.fx` files to native executables that **beat Python's speed!**
