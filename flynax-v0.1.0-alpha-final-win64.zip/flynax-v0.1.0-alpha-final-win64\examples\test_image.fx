main:
    let window = sdl_init(800, 600, "Flynax Image Test")
    
    print("Loading image...")
    let tex = sdl_load_texture(window, "examples/assets/logo.png")
    
    if (tex == 0):
        print("Failed to load texture!")
    else:
        print("Texture loaded successfully!")
    
    let running = 1
    while (running == 1):
        running = sdl_poll_events(window)
        
        # Clear background (Dark Gray)
        sdl_clear(window, 50, 50, 50)
        
        # Draw texture centered (200x200)
        # 800/2 - 200/2 = 300, 600/2 - 200/2 = 200
        sdl_draw_texture(window, tex, 300, 200, 200, 200)
        
        sdl_present(window)
        sdl_delay(16)
        
    sdl_destroy_texture(tex)
    sdl_quit(window)
