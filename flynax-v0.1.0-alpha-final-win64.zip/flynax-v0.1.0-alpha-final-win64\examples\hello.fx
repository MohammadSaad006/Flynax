# Simple Hello World in Flynax

main:
    print("Hello, Flynax!")
    let int x = 42
    print(x)
