main:
    let win = sdl_init(800, 600, "Flynax UI/UX Demo")
    ui_init(win)
    
    let running = 1
    let show_popup = 0
    let counter = 0
    let x_pos = 100
    
    while (running == 1):
        running = sdl_poll_events(win)
        
        # Simple animation logic
        counter = counter + 1
        x_pos = 100 + (counter)
        if (x_pos > 600):
            counter = 0
        
        sdl_clear(win, 15, 15, 25) # Dark stylish background
        
        ui_begin_frame()
        
        # Sidebar with "Glassmorphism" effect (alpha 150)
        ui_panel(0, 0, 220, 600, 40, 40, 60, 180)
        ui_label(20, 30, "FLYNAX ENGINE", 24, 80, 150, 255)
        ui_label(20, 70, "v0.1.0-alpha", 14, 150, 150, 170)
        
        if (ui_button(30, 120, 160, 40, "Toggle Modal")):
            if (show_popup == 0):
                show_popup = 1
            else:
                show_popup = 0
            
        if (ui_button(30, 180, 160, 40, "Reset Anim")):
            counter = 0
            
        # Draw some animated objects
        sdl_draw_rect(win, x_pos, 300, 60, 60, 0, 120, 255)
        ui_label(x_pos, 270, "Flowing...", 16, 200, 220, 255)
        
        # Floating Modal Window
        if (show_popup == 1):
            ui_panel(280, 180, 340, 240, 60, 60, 85, 240)
            ui_label(300, 210, "Component Modal", 24, 255, 255, 255)
            ui_label(300, 260, "This is a native UI", 16, 180, 180, 200)
            ui_label(300, 285, "component built in C.", 16, 180, 180, 200)
            
            if (ui_button(370, 340, 160, 40, "Confirm")):
                show_popup = 0
                print("Modal Confirmed!")
        
        ui_end_frame()
        sdl_present(win)
        sdl_delay(16)
        
    sdl_quit(win)
