# Simple SDL2 Window Test
# Creates a window with a colored background

main:
    print("Creating SDL2 window...")
    
    # Create 800x600 window
    let window = sdl_init(800, 600, "My First Flynax Window!")
    
    if (window == 0):
        print("Failed to create window!")
    
    print("Window created! Press X to close.")
    
    # Main loop
    let running = 1
    while (running == 1):
        # Poll events (returns 0 if quit)
        running = sdl_poll_events(window)
        
        # Clear to dark blue
        sdl_clear(window, 30, 60, 120)
        
        # Draw a red rectangle
        sdl_draw_filled_rect(window, 100, 100, 200, 150, 255, 0, 0)
        
        # Draw a green circle
        sdl_draw_circle(window, 400, 300, 50, 0, 255, 0)
        
        # Draw a yellow line
        sdl_draw_line(window, 0, 0, 800, 600, 255, 255, 0)
        
        # Present to screen
        sdl_present(window)
        
        # Small delay for ~60 FPS
        sdl_delay(16)
    
    # Cleanup
    sdl_quit(window)
    print("Window closed!")
