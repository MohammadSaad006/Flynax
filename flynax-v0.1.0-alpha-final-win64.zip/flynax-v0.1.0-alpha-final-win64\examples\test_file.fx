# Test File I/O

import file

main:
    # Write to file
    let bool success = file.write("test.txt", "Hello from Flynax!")
    print(success)
    
    # Read from file
    let string content = file.read("test.txt")
    print(content)
    
    # Append to file
    file.append("test.txt", "\nAppended line!")
    
    # Read again
    let string updated = file.read("test.txt")
    print(updated)
    
    # Check existence
    let bool exists = file.exists("test.txt")
    print(exists)
    
    # Delete file
    file.delete("test.txt")
