# Simple Neural Network Example in Flynax
# Demonstrates ML capabilities for everyone to use

# This example shows a conceptual neural network implementation
# The actual implementation would require proper array/matrix handling
# which is represented here with the new ML functions

main:
:
    print("=== Simple Neural Network in Flynax ===")
    
    # Initialize simple weights and biases (conceptual)
    # In a real implementation, we'd have proper matrix operations
    print("Initializing neural network...")
    
    # Example: Simple perceptron with one input
    let float input_value = 0.8
    let float weight = 0.6
    let float bias = 0.2
    
    print("Input: ")
    print(input_value)
    print("Weight: ")
    print(weight)
    print("Bias: ")
    print(bias)
    
    # Forward pass: compute weighted sum
    let float weighted_sum = input_value * weight + bias
    print("Weighted sum: ")
    print(weighted_sum)
    
    # Apply activation function
    let float output = ml_sigmoid(weighted_sum)
    print("Output after sigmoid: ")
    print(output)
    
    # Example: Multiple inputs (conceptual)
    print("\nMultiple input example:")
    let inputs = [0.5, 0.3, 0.8]  # Input vector
    let weights = [0.2, 0.7, 0.4]  # Weight vector
    # Note: In real implementation, we'd have proper dot product function
    
    # Simulate a simple calculation
    let float sum1 = inputs[0] * weights[0]  # This would need array indexing implementation
    let float sum2 = inputs[1] * weights[1]
    let float sum3 = inputs[2] * weights[2]
    let float total = sum1 + sum2 + sum3 + bias
    
    let float final_output = ml_sigmoid(total)
    print("Multi-input result: ")
    print(final_output)
    
    # Example: Error handling in ML context
    try:
        print("\nTesting error handling...")
        
        # Simulate training step (conceptual)
        let float predicted = 0.7
        let float actual = 0.9
        
        # Calculate error (conceptual - would use proper loss function)
        let float error = actual - predicted
        print("Prediction error: ")
        print(error)
        
        # Apply activation to error (for demonstration)
        let float error_signal = ml_sigmoid(error)
        print("Error signal: ")
        print(error_signal)
        
    catch(Error):
        print("ML error occurred: ")
        print(ex)
    
    # Example: Using ML functions for different purposes
    print("\nDifferent ML function examples:")
    
    # ReLU activation (common in deep learning)
    let float relu_val = ml_relu(-0.5)
    print("ReLU of -0.5: ")
    print(relu_val)
    
    let float relu_val2 = ml_relu(1.2)
    print("ReLU of 1.2: ")
    print(relu_val2)
    
    # Tanh activation
    let float tanh_val = ml_tanh(1.5)
    print("Tanh of 1.5: ")
    print(tanh_val)
    
    print("\n=== Neural Network Demo Complete ===")
    print("Flynax ML features enable:")
    print("- Easy-to-use activation functions")
    print("- Error handling for robust ML models")
    print("- Integration with standard programming constructs")
    print("- Array support for data handling")
    print("- Simple syntax for complex ML operations")