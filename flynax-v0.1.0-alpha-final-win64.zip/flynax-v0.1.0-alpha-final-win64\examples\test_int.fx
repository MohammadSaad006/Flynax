# Simple integer test

main:
    let int x = 42
    print(x)
    let int y = 100
    print(y)
