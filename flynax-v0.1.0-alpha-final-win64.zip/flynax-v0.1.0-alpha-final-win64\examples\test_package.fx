import "mypackage.utils" as utils

main:
    print("Testing package import:")
    
    # Test max function
    let int maximum = utils.max(15, 25)
    print("Max of 15 and 25 =")
    print(maximum)
    
    # Test min function
    let int minimum = utils.min(15, 25)
    print("Min of 15 and 25 =")
    print(minimum)
    
    # Test constant
    let int max_val = utils.max_value
    print("Max value constant =")
    print(max_val)
    
    print("Package test completed!")