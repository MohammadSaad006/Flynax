# Minimal StdLib Test
# Works with current parser

main:
    print("=== STDLIB TEST ===")
    
    # Math works!
    print("\nMath Pi:")
    print(math_pi())
    
    print("Sqrt(16):")
    print(math_sqrt(16.0))
    
    print("Max(10, 25):")
    print(math_max(10, 25))
    
    print("Random 1-100:")
    print(math_random(1, 100))
    
    print("\n=== SUCCESS ===")
