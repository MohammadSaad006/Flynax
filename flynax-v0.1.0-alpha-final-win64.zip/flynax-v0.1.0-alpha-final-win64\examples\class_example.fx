# Class example demonstrating Flynax syntax

class Point(int x, int y):
    
    move(int dx, int dy):
        x = x + dx
        y = y + dy
    
    display():
        print(x)
        print(y)

main:
    p = Point(10, 20)
    p.move(5, 5)
    p.display()
