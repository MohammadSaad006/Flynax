# Comprehensive Standard Library Demo
# Shows arrays, strings, and math working together

main:
    print("======================")
    print("FLYNAX STANDARD LIBRARY")
    print("======================")
    
    # === ARRAYS ===
    print("\n[ARRAYS]")
    let numbers = array_new()
    array_push(numbers, 10)
    array_push(numbers, 20)
    array_push(numbers, 30)
    array_push(numbers, 40)
    
    print("Array created with 4 elements")
    print("Length:")
    print(array_length(numbers))
    
    # === STRINGS ===
    print("\n[STRINGS]")
    let greeting = string_concat("Hello", " Flynax!")
    print(greeting)
    
    let upper = string_upper("flynax rocks")
    print("Uppercase:")
    print(upper)
    
    # String split
    let parts = string_split("apple,banana,cherry", ",")
    print("\nSplit 'apple,banana,cherry' by ',':")
    let int i = 0
    while (i < string_array_length(parts)):
        print(string_array_get(parts, i))
        i = i + 1
    
    # === MATH ===
    print("\n[MATH]")
    print("Pi:")
    print(math_pi())
    
    let float sqrt_result = math_sqrt(25.0)
    print("Sqrt(25):")
    print(sqrt_result)
    
    let int max = math_max(15, 42)
    print("Max(15, 42):")
    print(max)
    
    # === COMBINED EXAMPLE ===
    print("\n[COMBINED: Generate random scores]")
    let scores = array_new()
    let int j = 0
    while (j < 5):
        let int score = math_random(50, 100)
        array_push(scores, score)
        j = j + 1
    
    print("Generated 5 random scores (50-100):")
    let int k = 0
    while (k < array_length(scores)):
        print(array_get(scores, k))
        k = k + 1
    
    # Calculate average
    let int sum = 0
    let int m = 0
    while (m < array_length(scores)):
        sum = sum + array_get(scores, m)
        m = m + 1
    
    print("\nSum:")
    print(sum)
    
    array_free(scores)
    array_free(numbers)
    
    print("\n======================")
    print("STDLIB DEMO COMPLETE!")
    print("======================")
