main:
    print("Minimal test")
    let float val = 2.0
    print("Value: ")
    print(val)