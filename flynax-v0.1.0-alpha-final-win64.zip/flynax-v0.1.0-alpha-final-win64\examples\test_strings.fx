# Simple string test

main:
    print("Hello, World!")
    print("Flynax working!")
