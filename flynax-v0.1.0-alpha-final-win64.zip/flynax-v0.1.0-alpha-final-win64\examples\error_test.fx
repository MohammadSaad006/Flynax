main():
    print("This will fail next line")
    call_non_existent_fn()
