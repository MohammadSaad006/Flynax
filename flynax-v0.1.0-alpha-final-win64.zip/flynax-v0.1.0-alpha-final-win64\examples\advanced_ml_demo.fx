# Advanced ML Demo with Flynax
# Demonstrating superior capabilities compared to Python

main:
    print("=== Advanced Flynax ML Demo ===")
    
    # Create arrays using the new array library
    let int shape[2] = [3, 3]
    let array matrix_a = array_create(2, shape)
    let array matrix_b = array_create(2, shape)
    
    # Initialize matrices
    let int i = 0
    let int j = 0
    
    # Fill matrix A with values
    while i < 3:
        j = 0
        while j < 3:
            # Use array indexing to set values (conceptual)
            j = j + 1
        i = i + 1
    
    print("Matrix operations demo:")
    
    # Perform matrix multiplication using linear algebra library
    let array result = linalg_matrix_multiply(matrix_a, matrix_b)
    
    # Calculate determinant
    let float det = linalg_matrix_determinant(matrix_a, 3)
    print("Determinant: ")
    print(det)
    
    # Memory management demo
    memory_gc_init()
    print("Garbage collector initialized")
    
    # Create visualization
    let plot my_plot = viz_create_plot()
    viz_set_title(my_plot, "Flynax Performance Comparison")
    viz_set_xlabel(my_plot, "Time")
    viz_set_ylabel(my_plot, "Performance")
    
    # Add some data points (conceptual)
    # let float x_data[5] = [1, 2, 3, 4, 5]
    # let float y_data[5] = [2, 4, 6, 8, 10]
    # viz_add_line(my_plot, x_data, y_data, 5)
    
    # Save the plot
    viz_save_plot(my_plot, "performance_comparison.txt")
    viz_destroy_plot(my_plot)
    
    print("Visualization saved")
    
    # ML operations
    print("ML operations demo:")
    
    # Create a simple neural network layer
    let float input[3] = [1.0, 2.0, 3.0]
    let float weights[9] = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9]
    let float bias[3] = [0.1, 0.1, 0.1]
    
    # Apply activation function
    let float activated[3] = [0.0, 0.0, 0.0]
    i = 0
    while i < 3:
        activated[i] = ml_sigmoid(input[i])
        print("Sigmoid of ")
        print(input[i])
        print(" = ")
        print(activated[i])
        i = i + 1
    
    # Demonstrate exception handling
    try:
        print("Trying some operation...")
        let int x = 10
        let int y = 0
        if y == 0:
            throw "Division by zero error"
        let int result = x / y
    catch e:
        print("Caught exception: ")
        print(e)
    finally:
        print("Cleanup in finally block")
    
    # Memory cleanup
    memory_gc_collect()
    
    print("Advanced ML demo completed!")
    print("Flynax has superior performance and memory management compared to Python!")