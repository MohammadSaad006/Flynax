module MyMath:

    # Function to add two integers
    add(int a, int b): int
        return a + b
    
    # Function to multiply two integers
    multiply(int a, int b): int
        return a * b
    
    # Function to calculate square
    square(int a): int
        return a * a
    
    # A constant
    let pi = 314159