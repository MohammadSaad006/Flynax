main:
    let win = sdl_init(800, 600, "Flynax Text Test")
    
    print("Loading font...")
    let font = sdl_load_font("examples/assets/font.ttf", 64)
    
    if (font == 0):
        print("Failed to load font! Check examples/assets/font.ttf")
    else:
        print("Font loaded!")

    # Render Text (White)
    let tex = sdl_render_text(win, font, "Hello from Flynax!", 255, 255, 255)
    
    if (tex == 0):
        print("Failed to render text!")
    
    # Get dimensions
    let w = sdl_texture_width(tex)
    let h = sdl_texture_height(tex)
    
    print("Text size calculated.")
    
    let running = 1
    while (running == 1):
        running = sdl_poll_events(win)
        
        sdl_clear(win, 50, 0, 50) # Purple background
        
        # Center the text
        let cx = 400
        let cy = 300
        let x = cx - (w / 2)
        let y = cy - (h / 2)
        
        sdl_draw_texture(win, tex, x, y, w, h)
        
        sdl_present(win)
        sdl_delay(16)
        
    sdl_destroy_texture(tex)
    sdl_destroy_font(font)
    sdl_quit(win)
