# examples/web_hello.fx  - Flynax Web Demo (Clean Syntax)
# Notice how much simpler this is! No extern declarations needed —
# common DOM/CSS functions are built right into Flynax.
#
# Compile:  .\flynax.exe examples\web_hello.fx --target=wasm
# Preview:  open examples\web_hello.html (needs HTTP server)

# --- Import the Web Standard Library ---
import "web"

# App-specific WASM exports (counter state managed by JS)
extern flynax_counter_increment(): int
extern flynax_counter_reset(): int

# Callback: called when user clicks "+ Increment"
increment_counter():
    int val = flynax_counter_increment()
    flynax_dom_update_int_by_id("counter", val)

# Callback: called when user clicks "Reset"
reset_counter():
    int val = flynax_counter_reset()
    flynax_dom_update_int_by_id("counter", val)

main():
    # --- Global CSS (injected once into <head>) ---
    flynax_css_inject("
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:system-ui,sans-serif;background:#0d0d16;min-height:100vh;display:flex;align-items:center;justify-content:center}
      .wrap{width:100%;max-width:520px;padding:1.5rem}
      .card{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:20px;padding:2rem;backdrop-filter:blur(12px)}
      h1{font-size:2.2rem;font-weight:800;background:linear-gradient(135deg,#a855f7,#3b82f6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:.4rem}
      .sub{color:#9ca3af;margin-bottom:1.8rem;font-size:.95rem}
      .lbl{font-size:.75rem;text-transform:uppercase;letter-spacing:1.5px;color:#6b7280;margin-bottom:.5rem}
      .counter{font-size:5rem;font-weight:900;text-align:center;color:#a855f7;line-height:1;padding:1rem 0}
      .btns{display:flex;gap:.75rem;margin-top:.5rem}
      .btn{flex:1;padding:.75rem;border:none;border-radius:12px;font-size:.95rem;font-weight:600;cursor:pointer;transition:all .15s}
      .btn-p{background:linear-gradient(135deg,#7c3aed,#2563eb);color:#fff}
      .btn-p:hover{transform:translateY(-2px);box-shadow:0 8px 20px rgba(124,58,237,.35)}
      .btn-s{background:rgba(255,255,255,.08);color:#e0e0ff;border:1px solid rgba(255,255,255,.12)}
      .btn-s:hover{background:rgba(255,255,255,.14)}
      .divider{height:1px;background:rgba(255,255,255,.07);margin:1.5rem 0}
      .feat{list-style:none}
      .feat li{padding:.45rem 0;color:#9ca3af;font-size:.9rem}
      .feat li::before{content:'✦ ';color:#a855f7}
    ")

    # --- Build the page ---
    int body = body()
    int wrap  = elClass("div", "wrap")
    int card  = elClass("div", "card")

    # Title
    int h1   = elText("h1", "Hello from Flynax!")
    int sub  = elText("p",  "Built with Flynax → compiled to WebAssembly")
    flynax_dom_add_class(sub, "sub")

    # Counter display
    int lbl     = elText("div", "INTERACTIVE COUNTER")
    flynax_dom_add_class(lbl, "lbl")
    int disp = elClass("div", "counter")
    flynax_dom_set_id(disp, "counter")
    flynax_dom_set_text(disp, "0")

    # Buttons
    int btns  = elClass("div", "btns")
    int btnP  = elText("button", "+ Increment")
    flynax_dom_add_class(btnP, "btn")
    flynax_dom_add_class(btnP, "btn-p")
    flynax_dom_on_click(btnP, "increment_counter")

    int btnR  = elText("button", "Reset")
    flynax_dom_add_class(btnR, "btn")
    flynax_dom_add_class(btnR, "btn-s")
    flynax_dom_on_click(btnR, "reset_counter")

    flynax_dom_append_child(btns, btnP)
    flynax_dom_append_child(btns, btnR)

    # Divider + features
    int divider = elClass("div", "divider")
    int featLbl = elText("div", "WHY FLYNAX?")
    flynax_dom_add_class(featLbl, "lbl")

    int feats = elClass("ul", "feat")
    int f1 = elText("li", "Compiles to native + WebAssembly")
    int f2 = elText("li", "Python-like syntax, C++ speed")
    int f3 = elText("li", "Websites, apps, games — one language")
    int f4 = elText("li", "Full DOM & CSS API via WASM bridge")

    flynax_dom_append_child(feats, f1)
    flynax_dom_append_child(feats, f2)
    flynax_dom_append_child(feats, f3)
    flynax_dom_append_child(feats, f4)

    # Assemble
    flynax_dom_append_child(card, h1)
    flynax_dom_append_child(card, sub)
    flynax_dom_append_child(card, lbl)
    flynax_dom_append_child(card, disp)
    flynax_dom_append_child(card, btns)
    flynax_dom_append_child(card, divider)
    flynax_dom_append_child(card, featLbl)
    flynax_dom_append_child(card, feats)
    flynax_dom_append_child(wrap, card)
    flynax_dom_append_child(body, wrap)

    flynax_console_log("Flynax ready!")
    return 0
