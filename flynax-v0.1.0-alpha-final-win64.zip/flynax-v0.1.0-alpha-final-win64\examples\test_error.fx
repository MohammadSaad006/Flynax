# Intentional Semantic Error Test

main():
    int x = 10
    
    # This function doesn't exist
    this_function_does_not_exist(x)
    
    print("Should not reach here")
