main:
    print("Map/Dictionary Test starting...")
    
    let scores = map_new()
    
    print("Setting values...")
    map_set(scores, "Antigravity", 100)
    map_set(scores, "User", 95)
    map_set(scores, "Flynax", 200)
    
    print("Retrieving values:")
    print("Antigravity: ")
    print(map_get(scores, "Antigravity"))
    
    print("User: ")
    print(map_get(scores, "User"))
    
    print("Flynax: ")
    print(map_get(scores, "Flynax"))
    
    print("Checking contains:")
    if map_contains(scores, "User"):
        print("User exists in map!")
    
    if map_contains(scores, "Missing") == 0:
        print("Missing key correctly not found.")
    
    print("Map size: ")
    print(map_size(scores))
    
    print("Removing User...")
    map_remove(scores, "User")
    
    print("New map size: ")
    print(map_size(scores))
    
    if map_contains(scores, "User") == 0:
        print("User successfully removed.")
    
    map_free(scores)
    print("Map test complete!")
