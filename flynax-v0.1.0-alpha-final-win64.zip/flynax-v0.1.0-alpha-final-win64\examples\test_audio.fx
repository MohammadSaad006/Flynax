main:
    let win = sdl_init(400, 300, "Flynax Audio Test")
    
    print("Loading sound...")
    let sound = sdl_load_sound("examples/assets/beep.wav")
    
    if (sound == 0):
        print("Failed to load sound!")
    else:
        print("Sound loaded! Press SPACE (Scancode 44) to play.")
    
    let running = 1
    while (running == 1):
        running = sdl_poll_events(win)
        
        # Spacebar = 44
        if (sdl_key_pressed(44) == 1):
            print("BEEP!")
            sdl_play_sound(sound, 0)
            sdl_delay(200)
            
        sdl_clear(win, 0, 100, 0)
        sdl_present(win)
        sdl_delay(16)
        
    sdl_destroy_sound(sound)
    sdl_quit(win)
