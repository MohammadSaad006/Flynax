# Test WASM Imports

extern flynax_print_int(int value): void
extern flynax_dom_create_element(string tag): int

main():
    int elementId = flynax_dom_create_element("div")
    flynax_print_int(elementId)
    return 0
