main:
    print("Sanity Check: Compiler is working!")
