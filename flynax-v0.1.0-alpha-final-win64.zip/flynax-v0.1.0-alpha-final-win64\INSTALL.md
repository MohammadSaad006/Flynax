# Flynax Installation Guide

Thank you for choosing Flynax! Follow these steps to set up the Flynax ecosystem on your machine.

## 📋 Prerequisites

Flynax uses **Clang** as its backend compiler to generate high-performance native binaries.

1.  **Install LLVM (includes Clang):**
    -   Download from: [LLVM Releases](https://github.com/llvm/llvm-project/releases)
    -   Or install via winget:
        ```powershell
        winget install -e --id LLVM.LLVM
        ```
2.  **Verify Clang:**
    -   Open a terminal and run `clang --version`. If it works, you're ready!

---

## 🚀 Setup Flynax

1.  **Extract the Zip:**
    -   Extract the `flynax-win64.zip` to a folder (e.g., `C:\flynax`).

2.  **Add to PATH:**
    -   Add the `bin` directory (e.g., `C:\flynax\bin`) to your System Environment variables (PATH).
    -   *Tip: Search for "Edit the system environment variables" in Start Menu.*

3.  **Verify Installation:**
    -   Restart your terminal.
    -   Run `flynax --version` to see the Flynax version.

---

## 🧪 Run Your First Program

1.  Navigate to the `examples` folder.
2.  Run the hello world program:
    ```powershell
    flynax run hello.fx
    ```

---

## 📦 Package Management

To install new modules from the cloud:
```powershell
flynax install math
```

Happy Coding with Flynax!
