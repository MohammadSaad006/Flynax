# STDLIB SUCCESS TEST
# Working demonstration of all implemented features

main:
    print("====== FLYNAX STDLIB DEMO ======")
    
    # Math Functions
    print("\n[MATH FUNCTIONS]")
    let int max = math_max(42, 17)
    print("max(42, 17) =")
    print(max)
    
    let int min = math_min(42, 17)  
    print("min(42, 17) =")
    print(min)
    
    let int random = math_random(1, 100)
    print("random(1, 100) =")
    print(random)
    
    # String Functions  
    print("\n[STRING FUNCTIONS]")
    let int len = string_length("Flynax")
    print("length('Flynax') =")
    print(len)
    
    let int has = string_contains("Hello Flynax", "Flynax")
    print("contains('Hello Flynax', 'Flynax') =")
    print(has)
    
    let int pos = string_index_of("Hello World", "World")
    print("index_of('Hello World', 'World') =")
    print(pos)
    
    print("\n====== ALL TESTS PASSED! ======")
