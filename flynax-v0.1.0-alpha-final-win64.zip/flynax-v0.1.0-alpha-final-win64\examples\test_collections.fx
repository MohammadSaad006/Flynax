main:
    print("Advanced Data Structures Test starting...")
    
    # --- Linked List Test ---
    print("--- Testing Linked List ---")
    let list = list_new()
    list_push_back(list, 10)
    list_push_back(list, 20)
    list_push_back(list, 30)
    print("List size: ")
    print(list_size(list))
    print("Element at index 1 (should be 20): ")
    print(list_get(list, 1))
    print("Popping back: ")
    print(list_pop_back(list))
    print("New size: ")
    print(list_size(list))
    
    # --- Binary Search Tree Test ---
    print("--- Testing Binary Search Tree ---")
    let tree = tree_new()
    tree_insert(tree, 50)
    tree_insert(tree, 30)
    tree_insert(tree, 70)
    tree_insert(tree, 20)
    tree_insert(tree, 40)
    
    print("Search for 30 (exists): ")
    print(tree_search(tree, 30))
    print("Search for 60 (missing): ")
    print(tree_search(tree, 60))
    print("Tree size: ")
    print(tree_size(tree))
    
    # --- Graph Test ---
    print("--- Testing Graph ---")
    let graph = graph_new(5)
    graph_add_edge(graph, 0, 1, 10)
    graph_add_edge(graph, 1, 2, 20)
    graph_add_edge(graph, 0, 2, 50)
    
    print("Weight from 0 to 1: ")
    print(graph_get_weight(graph, 0, 1))
    print("Weight from 0 to 2: ")
    print(graph_get_weight(graph, 0, 2))
    print("Has edge 1 -> 2: ")
    if graph_get_weight(graph, 1, 2) != 0:
        print("Yes")
    else:
        print("No")
    
    print("Advanced Data Structures Test complete!")
