# COMPREHENSIVE STANDARD LIBRARY TEST
# Tests ALL new features: Arrays, Strings, Math
# This validates the entire stdlib integration

main:
    print("========================================")
    print("FLYNAX STANDARD LIBRARY - FULL TEST")
    print("========================================")
    
    # ===== TEST 1: ARRAYS =====
    print("\n[TEST 1: Arrays]")
    let arr = array_new()
    
    # Push elements
    array_push(arr, 100)
    array_push(arr, 200)
    array_push(arr, 300)
    
    print("Created array with 3 elements")
    print("Length should be 3:")
    print(array_length(arr))
    
    # Get elements
    print("Get index 0 (should be 100):")
    print(array_get(arr, 0))
    
    print("Get index 2 (should be 300):")
    print(array_get(arr, 2))
    
    # Contains check
    print("Contains 200? (should be 1):")
    print(array_contains(arr, 200))
    
    print("Contains 999? (should be 0):")
    print(array_contains(arr, 999))
    
    # Index of
    print("Index of 300 (should be 2):")
    print(array_index_of(arr, 300))
    
    array_free(arr)
    print("✓ Array test passed!\n")
    
    # ===== TEST 2: STRINGS =====
    print("[TEST 2: Strings]")
    
    # Concatenation
    let str1 = "Hello"
    let str2 = " World"
    let combined = string_concat(str1, str2)
    print("Concat 'Hello' + ' World':")
    print(combined)
    
    # Length
    print("Length of 'Hello World' (should be 11):")
    print(string_length(combined))
    
    # Uppercase/Lowercase
    let upper = string_upper("flynax")
    print("Uppercase 'flynax':")
    print(upper)
    
    let lower = string_lower("ROCKS")
    print("Lowercase 'ROCKS':")
    print(lower)
    
    # Contains
    print("'Hello World' contains 'World'? (should be 1):")
    print(string_contains(combined, "World"))
    
    # Index of
    print("Index of 'World' in 'Hello World' (should be 6):")
    print(string_index_of(combined, "World"))
    
    # Substring
    let sub = string_substring("Hello World", 0, 5)
    print("Substring(0, 5) of 'Hello World':")
    print(sub)
    
    # Split
    print("\nSplit 'a,b,c' by ',':")
    let parts = string_split("a,b,c", ",")
    let int i = 0
    while (i < string_array_length(parts)):
        let part = string_array_get(parts, i)
        print(part)
        i = i + 1
    
    # Trim
    let trimmed = string_trim("  hello  ")
    print("\nTrimmed '  hello  ':")
    print(trimmed)
    
    # Replace
    let replaced = string_replace("foo bar foo", "foo", "baz")
    print("Replace 'foo' with 'baz' in 'foo bar foo':")
    print(replaced)
    
    print("✓ String test passed!\n")
    
    # ===== TEST 3: MATH =====
    print("[TEST 3: Math]")
    
    # Constants
    print("Pi:")
    print(math_pi())
    
    print("E:")
    print(math_e())
    
    # Absolute value
    print("\nAbs(-42) (should be 42):")
    print(math_abs(-42))
    
    # Min/Max
    print("Max(10, 25) (should be 25):")
    print(math_max(10, 25))
    
    print("Min(10, 25) (should be 10):")
    print(math_min(10, 25))
    
    # Square root
    print("\nSqrt(16.0) (should be 4.0):")
    print(math_sqrt(16.0))
    
    # Power
    print("Pow(2.0, 3.0) (should be 8.0):")
    print(math_pow(2.0, 3.0))
    
    # Rounding
    print("\nFloor(3.7) (should be 3.0):")
    print(math_floor(3.7))
    
    print("Ceil(3.2) (should be 4.0):")
    print(math_ceil(3.2))
    
    print("Round(3.5) (should be 4.0):")
    print(math_round(3.5))
    
    # Random
    print("\nRandom number between 1-10:")
    print(math_random(1, 10))
    
    print("Random float (0.0-1.0):")
    print(math_random_float())
    
    print("✓ Math test passed!\n")
    
    # ===== TEST 4: COMBINED USAGE =====
    print("[TEST 4: Combined - Real-world Example]")
    print("Building a simple task list...\n")
    
    # Simulate a task list with priorities
    let tasks = array_new()
    array_push(tasks, 100)  # High priority
    array_push(tasks, 200)  # Medium priority
    array_push(tasks, 100)  # High priority
    array_push(tasks, 50)   # Low priority
    
    print("Task priorities added")
    
    # Calculate average priority
    let int total = 0
    let int j = 0
    while (j < array_length(tasks)):
        total = total + array_get(tasks, j)
        j = j + 1
    
    print("Total priority points:")
    print(total)
    
    print("Task count:")
    print(array_length(tasks))
    
    # Find high priority tasks
    print("\nHigh priority task count (value=100):")
    let int high_count = 0
    let int k = 0
    while (k < array_length(tasks)):
        if (array_get(tasks, k) == 100):
            high_count = high_count + 1
        k = k + 1
    print(high_count)
    
    array_free(tasks)
    
    print("\n✓ Combined test passed!")
    
    # ===== FINAL SUMMARY =====
    print("\n========================================")
    print("ALL TESTS PASSED!")
    print("Standard Library is FULLY FUNCTIONAL")
    print("========================================")
