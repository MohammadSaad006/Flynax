main:
    print("Pointer Test starting...")
    
    let int x = 42
    print("x is initially: ")
    print(x)
    
    print("Taking address of x...")
    let int* p = &x
    
    print("Dereferencing p to get value of x:")
    print(*p)
    
    print("Modifying x via pointer (*p = 100)...")
    *p = 100
    
    print("New value of x: ")
    print(x)
    
    if x == 100:
        print("Pointer modification successful!")
    
    print("Pointer Test complete!")
