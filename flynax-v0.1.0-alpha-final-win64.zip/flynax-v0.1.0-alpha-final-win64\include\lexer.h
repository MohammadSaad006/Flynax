#pragma once

#include <memory>
#include <string>
#include <vector>

namespace flynax {

// Token types for Flynax language
enum class TokenType {
  // Literals
  IDENTIFIER,
  INTEGER,
  FLOAT,
  STRING,

  // Keywords
  CLASS,
  LET,
  IF,
  ELSE,
  WHILE,
  FOR,
  RETURN,
  MAIN,
  PRINT,
  IMPORT,
  AS,
  MODULE,
  FROM,
  TRY,
  CATCH,
  THROW,
  FINALLY,
  EXTERN,

  // Types
  INT,
  FLOAT_TYPE,
  STRING_TYPE,
  BOOL,

  // Operators
  PLUS,          // +
  MINUS,         // -
  STAR,          // *
  SLASH,         // /
  ASSIGN,        // =
  EQUAL,         // ==
  NOT_EQUAL,     // !=
  LESS,          // <
  GREATER,       // >
  LESS_EQUAL,    // <=
  GREATER_EQUAL, // >=
  AMPERSAND,     // &

  // Delimiters
  LPAREN,   // (
  RPAREN,   // )
  LBRACE,   // {
  RBRACE,   // }
  LBRACKET, // [
  RBRACKET, // ]
  COMMA,    // ,
  COLON,    // :
  DOT,      // .

  // Special
  NEWLINE,
  INDENT,
  DEDENT,
  EOF_TOKEN,
  INVALID
};

struct Token {
  TokenType type;
  std::string value;
  int line;
  int column;
  std::string filename; // Source file this token came from

  Token(TokenType t, const std::string &v, int l, int c,
        const std::string &f = "")
      : type(t), value(v), line(l), column(c), filename(f) {}
};

class Lexer {
public:
  Lexer(const std::string &source, const std::string &filename = "unknown");

  std::vector<Token> tokenize();

private:
  std::string source_;
  std::string filename_;
  size_t pos_;
  int line_;
  int column_;
  std::vector<int> indent_stack_;

  char peek(int offset = 0) const;
  char advance();
  void skipWhitespace();
  void skipComment();

  Token makeToken(TokenType type, const std::string &value);
  Token readNumber();
  Token readIdentifier();
  Token readString();

  bool isAtEnd() const;
  bool isDigit(char c) const;
  bool isAlpha(char c) const;
  bool isAlphaNumeric(char c) const;

  TokenType getKeywordType(const std::string &word);
};

} // namespace flynax
