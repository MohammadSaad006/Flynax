#pragma once

#include "ast.h"
#include "lexer.h"
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace flynax {

class Parser {
public:
  explicit Parser(const std::vector<Token> &tokens);

  std::unique_ptr<Program> parse();

private:
  std::vector<Token> tokens_;
  size_t pos_;

  // Helper methods
  Token peek(int offset = 0) const;
  Token advance();
  bool match(TokenType type);
  bool check(TokenType type) const;
  Token expect(TokenType type, const std::string &message);

  // Parsing methods
  std::unique_ptr<Statement> parseStatement();
  std::unique_ptr<Statement> parseModule();
  std::unique_ptr<VariableDecl> parseVariableDecl();
  std::unique_ptr<Assignment> parseAssignment();
  std::unique_ptr<FunctionDecl> parseFunction();
  std::unique_ptr<ExternDecl> parseExtern();
  std::unique_ptr<Statement> parseIf();
  std::unique_ptr<Statement> parseWhile();
  std::string parseType();
  std::unique_ptr<ClassDecl> parseClass();
  std::vector<std::unique_ptr<Statement>> parseBlock();

  std::unique_ptr<Expression> parseExpression();
  std::unique_ptr<Expression> parseComparison();
  std::unique_ptr<Expression> parseTerm();
  std::unique_ptr<Expression> parseFactor();
  std::unique_ptr<Expression> parseUnary();
  std::unique_ptr<Expression> parsePrimary();
  std::unique_ptr<Expression> parseFunctionCall(const std::string &name);

  std::unique_ptr<Statement> parseTryCatch();

  bool isAtEnd() const;
  std::string extractModuleNameFromPath(const std::string &path);

  template <typename T, typename... Args>
  std::unique_ptr<T> makeNode(Args &&...args) {
    auto node = std::make_unique<T>(std::forward<Args>(args)...);
    if (!isAtEnd()) {
      node->line = peek().line;
      node->column = peek().column;
    }
    return node;
  }

  std::string currentNamespace_;
  bool isInFunction_;
  bool isInClass_;
  std::map<std::string, std::string> importMapping_; // alias -> fullNamespace
};

} // namespace flynax
