# Test Math Max
main:
    print("Testing math_max:")
    let int result = math_max(10, 25)
    print(result)
