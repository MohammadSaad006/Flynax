# Flynax Syntax Unification Test

main():
    # Built-in type without let
    int x = 10
    print(x)
    
    # Built-in type with let (should still work for backward compatibility)
    let int y = 20
    print(y)
    
    # String type without let
    string name = "Flynax"
    print(name)
    
    # Re-assignment (should be ExpressionStatement -> Assignment)
    x = 100
    print(x)
