# Test Standard Library: Math

main:
    print("=== Math Test ===")
    
    # Constants
    print("Pi:")
    print(math_pi())
    print("E:")
    print(math_e())
    
    # Basic operations
    let int abs_val = math_abs(-42)
    print("\nAbs(-42):")
    print(abs_val)
    
    let int max_val = math_max(10, 20)
    print("Max(10, 20):")
    print(max_val)
    
    # Square root
    let float sqrt_val = math_sqrt(16.0)
    print("\nSqrt(16):")
    print(sqrt_val)
    
    # Power
    let float pow_val = math_pow(2.0, 3.0)
    print("Pow(2, 3):")
    print(pow_val)
    
    # Rounding
    let float floor_val = math_floor(3.7)
    let float ceil_val = math_ceil(3.2)
    print("\nFloor(3.7):")
    print(floor_val)
    print("Ceil(3.2):")
    print(ceil_val)
    
    # Random
    print("\nRandom numbers (1-10):")
    let int r1 = math_random(1, 10)
    let int r2 = math_random(1, 10)
    let int r3 = math_random(1, 10)
    print(r1)
    print(r2)
    print(r3)
    
    print("\n=== Math Test Complete ===")
