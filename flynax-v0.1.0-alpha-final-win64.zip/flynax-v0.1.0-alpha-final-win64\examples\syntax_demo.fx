# Comprehensive syntax demonstration in Flynax

# Simple function definition
add(int a, int b): int
    return a + b

# Function with exception handling
divide(int numerator, int denominator): int
    try:
        if denominator == 0:
            throw("Division by zero error")
            return 0
        else:
            return numerator / denominator
    
    catch(Error):
        print("Error in division function")
        return -1

# Main function
main:
    print("Comprehensive syntax demo")
    
    # Variable declarations
    let int x = 10
    let int y = 5
    
    # Function calls
    let int sum = add(x, y)
    print("Sum: ")
    print(sum)
    
    # Division with exception handling
    let int result = divide(10, 2)
    print("Division result: ")
    print(result)
    
    # Division by zero to test exception
    let int result2 = divide(10, 0)
    print("Division by zero result: ")
    print(result2)
    
    # Control flow
    if x > y:
        print("x is greater than y")
    else:
        print("x is not greater than y")
    
    # Loop
    let int i = 0
    while i < 3:
        print("Loop iteration: ")
        print(i)
        i = i + 1
    
    print("Syntax demo completed")