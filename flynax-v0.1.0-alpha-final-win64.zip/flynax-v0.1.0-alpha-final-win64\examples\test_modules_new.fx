import "examples/mymath.fx" as math

main:
    print("Testing module functions:")
    
    # Test addition
    let int sum = math.add(10, 20)
    print("10 + 20 =")
    print(sum)
    
    # Test multiplication
    let int product = math.multiply(5, 6)
    print("5 * 6 =")
    print(product)
    
    # Test square
    let int sq = math.square(7)
    print("7^2 =")
    print(sq)
    
    # Test constant
    let int pi_val = math.pi
    print("Pi constant =")
    print(pi_val)
    
    print("Module test completed!")