# Array Test with Type Inference!

main:
    print("====== ARRAY TEST ======")
    
    # Create array - no type needed!
    let arr = array_new()
    
    # Add elements
    array_push(arr, 10)
    array_push(arr, 20)
    array_push(arr, 30)
    
    print("\nAdded 3 elements")
    print("Length:")
    print(array_length(arr))
    
    print("\nGet element at index 0:")
    print(array_get(arr, 0))
    
    print("\nGet element at index 2:")
    print(array_get(arr, 2))
    
    # Test contains
    print("\nContains 20?")
    print(array_contains(arr, 20))
    
    print("\nContains 99?")
    print(array_contains(arr, 99))
    
    # Test index_of
    print("\nIndex of 30:")
    print(array_index_of(arr, 30))
    
    array_free(arr)
    
    print("\n====== ARRAY TEST PASSED! ======")
