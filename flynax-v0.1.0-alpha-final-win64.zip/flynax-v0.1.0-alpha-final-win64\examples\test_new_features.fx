main:
:
    print("Testing Flynax New Features")
    
    # Test exception handling
    try:
        let int x = 10
        let int y = 0
        if y == 0:
            throw "Division by zero"
        let int result = x / y
    catch e:
        print("Caught exception: ")
        print(e)
    finally:
        print("Finally block executed")
    
    # Test ML functions
    let float val = 2.0
    let float sigmoid_result = ml_sigmoid(val)
    print("Sigmoid of 2.0: ")
    print(sigmoid_result)
    
    let float relu_result = ml_relu(val)
    print("ReLU of 2.0: ")
    print(relu_result)
    
    # Test memory management
    memory_gc_init()
    print("Memory management initialized")
    memory_gc_collect()
    
    # Test visualization (conceptual)
    let plot my_plot = viz_create_plot()
    viz_set_title(my_plot, "Test Plot")
    viz_save_plot(my_plot, "test_plot.txt")
    viz_destroy_plot(my_plot)
    print("Visualization completed")
    
    print("All new features working!")