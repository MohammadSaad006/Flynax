import "stdlib/web.fx"

main:
    print("Starting Flynax Web Server on port 8080...")
    
    # In this demo, we'll simulate a server loop for testing
    # since server_accept blocks and we want to verify the logic.
    
    # Simulated Request data
    let string raw = "GET /hello HTTP/1.1\r\nHost: localhost\r\n\r\n"
    
    print("Processing Simulated Request: ")
    print(raw)
    
    let req = Request(1, raw)
    let res = Response(1)
    let router = Router()
    
    router.handle(req, res)
    
    print("\nProcessing another request: /")
    let raw2 = "GET / HTTP/1.1\r\n\r\n"
    let req2 = Request(1, raw2)
    let res2 = Response(1)
    router.handle(req2, res2)
    
    print("Web Framework Verification Complete!")
