class Process:
    let int pid
    let int priority
    let string name
    
    init(int p, int prio, string n):
        this.pid = p
        this.priority = prio
        this.name = n

main:
    print("=== Flynax Kernel Simulation ===")
    
    # 1. Initialize System Structures
    let pid_map = map_new()       # PID -> Process Pointer
    let scheduler = tree_new()    # Priority-based BST
    let dmesg = list_new()        # System Log (Linked List)
    let wait_graph = graph_new(10) # Resource Dependency Graph
    
    print("[Kernel] Initializing Process Registry...")
    
    # 2. Create and Register Processes
    # We use pointers to the classes to store in the map/collections
    
    let p1 = Process(101, 5, "WebServer")
    let p2 = Process(102, 8, "Database")
    let p3 = Process(103, 3, "LogDaemon")
    
    # Store in PID Map (simulated pointers via map values)
    map_set(pid_map, "101", 1) # Marking as active
    map_set(pid_map, "102", 1)
    map_set(pid_map, "103", 1)
    
    # 3. Queue in Scheduler (BST)
    print("[Scheduler] Adding processes to Priority Tree...")
    tree_insert(scheduler, p1.priority)
    tree_insert(scheduler, p2.priority)
    tree_insert(scheduler, p3.priority)
    
    # 4. Simulate Resource Allocation via Graph
    # Process 101 waits for a resource held by Process 102
    print("[Kernel] Recording resource dependencies...")
    graph_add_edge(wait_graph, 0, 1, 1) # P101 -> P102
    graph_add_edge(wait_graph, 1, 2, 1) # P102 -> P103
    
    # 5. Log Events to Linked List
    list_push_back(dmesg, 101)
    list_push_back(dmesg, 102)
    list_push_back(dmesg, 103)
    
    # 6. Verify System Consistency
    print("\n--- Diagnostic Report ---")
    print("Total Processes tracked in map: ")
    print(map_size(pid_map))
    
    print("Highest Priority in Scheduler: ")
    # Simple BST search for priority 8
    if tree_search(scheduler, 8) == 1:
        print("Priority 8 (Database) is ready.")
    
    print("System Log Size (dmesg): ")
    print(list_size(dmesg))
    
    print("Checking for Deadlock (P101 -> P102): ")
    if graph_get_weight(wait_graph, 0, 1) == 1:
        print("Dependency link confirmed.")
    
    print("\n=== Kernel Simulation Complete ===")
