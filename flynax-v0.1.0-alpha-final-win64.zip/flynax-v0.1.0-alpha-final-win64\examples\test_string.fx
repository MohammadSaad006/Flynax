# Test Standard Library: Strings

main:
    print("=== String Test ===")
    
    # Concatenation
    let str1 = "Hello"
    let str2 = " World"
    let result = string_concat(str1, str2)
    print(result)
    
    # Length
    let int len = string_length(result)
    print("Length:")
    print(len)
    
    # Uppercase/Lowercase
    let upper = string_upper("hello")
    let lower = string_lower("WORLD")
    print("Upper:")
    print(upper)
    print("Lower:")
    print(lower)
    
    # Contains/IndexOf
    if (string_contains("Hello World", "World")):
        print("Contains 'World'")
    
    let int pos = string_index_of("Hello World", "World")
    print("Index of 'World':")
    print(pos)
    
    # Substring
    let sub = string_substring("Hello World", 0, 5)
    print("Substring(0, 5):")
    print(sub)
    
    # Split
    let parts = string_split("apple,banana,cherry", ",")
    print("\nSplit result:")
    let int i = 0
    while (i < string_array_length(parts)):
        let part = string_array_get(parts, i)
        print(part)
        i = i + 1
    
    # Trim
    let trimmed = string_trim("  hello  ")
    print("\nTrimmed:")
    print(trimmed)
    
    # Replace
    let replaced = string_replace("Hello World", "World", "Flynax")
    print("\nReplaced:")
    print(replaced)
    
    print("\n=== String Test Complete ===")
