# Machine Learning Demo in Flynax
# Demonstrates new ML/AI capabilities

main:
:
    print("=== Flynax Machine Learning Demo ===")
    
    # Test basic ML functions
    print("Testing activation functions...")
    
    # Test sigmoid activation
    let float x = 0.5
    let float sigmoid_result = ml_sigmoid(x)
    print("Sigmoid of 0.5: ")
    print(sigmoid_result)
    
    # Test ReLU activation
    let float relu_result = ml_relu(x)
    print("ReLU of 0.5: ")
    print(relu_result)
    
    # Test tanh activation
    let float tanh_result = ml_tanh(x)
    print("Tanh of 0.5: ")
    print(tanh_result)
    
    # Test with negative value
    let float neg_x = -1.0
    let float sigmoid_neg = ml_sigmoid(neg_x)
    print("Sigmoid of -1.0: ")
    print(sigmoid_neg)
    
    let float relu_neg = ml_relu(neg_x)
    print("ReLU of -1.0: ")
    print(relu_neg)
    
    # Example: Simple neural network operations
    print("\nTesting neural network operations...")
    
    # Simulate a simple forward pass (conceptual - actual implementation would need proper array handling)
    # For now, we'll demonstrate the function calls
    
    # Example: Using try-catch for error handling in ML
    try:
        print("ML operations in try block")
        
        # Simulate a simple model prediction (conceptual)
        let float input_val = 2.0
        let float weight = 0.5
        let float bias = 0.1
        let float linear = input_val * weight + bias  # Simple linear combination
        let float activated = ml_sigmoid(linear)      # Apply activation function
        
        print("Input: ")
        print(input_val)
        print("Linear output: ")
        print(linear)
        print("Activated output: ")
        print(activated)
        
    catch(Error):
        print("Error in ML operations: ")
        print(ex)
    
    # Demonstrate array usage for ML data (using our new array literals)
    print("\nTesting ML with arrays...")
    let features = [1.0, 2.0, 3.0, 4.0, 5.0]  # Input features
    print("Created feature array")
    
    # Example: Using module imports for ML (if we had an ML module)
    # import "ml_algorithms" as ml
    
    print("\n=== ML Demo Completed ===")
    print("Flynax now supports:")
    print("- Activation functions (sigmoid, relu, tanh)")
    print("- Loss functions (mse, cross-entropy)")
    print("- Neural network operations")
    print("- Array operations for ML data")
    print("- Error handling for ML operations")
    print("- Integration with existing features (modules, try-catch, etc.)")