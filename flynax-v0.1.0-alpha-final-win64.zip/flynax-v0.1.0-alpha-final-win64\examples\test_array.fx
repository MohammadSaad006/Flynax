# Test Standard Library: Arrays

main:
    print("=== Array/List Test ===")
    
    # Create array
    let arr = array_new()
    
    # Add elements
    array_push(arr, 10)
    array_push(arr, 20)
    array_push(arr, 30)
    array_push(arr, 40)
    array_push(arr, 50)
    
    print("Array length:")
    print(array_length(arr))
    
    # Access elements
    print("\nArray elements:")
    let int i = 0
    while (i < array_length(arr)):
        let int val = array_get(arr, i)
        print(val)
        i = i + 1
    
    # Test contains
    print("\nContains 30?")
    if (array_contains(arr, 30)):
        print("Yes!")
    
    print("Contains 99?")
    if (array_contains(arr, 99)):
        print("Yes!")
    else:
        print("No!")
    
    # Test index_of
    print("\nIndex of 40:")
    let int idx = array_index_of(arr, 40)
    print(idx)
    
    # Insert
    array_insert(arr, 2, 25)
    print("\nAfter insert at index 2:")
    let int j = 0
    while (j < array_length(arr)):
        print(array_get(arr, j))
        j = j + 1
    
    # Remove
    array_remove(arr, 0)
    print("\nAfter removing index 0:")
    let int k = 0
    while (k < array_length(arr)):
        print(array_get(arr, k))
        k = k + 1
    
    array_free(arr)
    print("\n=== Array Test Complete ===")
