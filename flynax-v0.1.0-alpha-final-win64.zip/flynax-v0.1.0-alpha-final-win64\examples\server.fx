# Native Flynax Web Server

main:
    let int port = 8080
    print("Starting Flynax Web Server on port 8080...")
    
    # Initialize server
    let int server = server_init(port)
    
    print("Waiting for connections...")
    
    # Handle one connection for test
    let int client = server_accept(server)
    print("Client connected!")
    
    # Read request
    let string req = server_read(client)
    print("Received request:")
    print(req)
    
    # Send response
    let string response = "HTTP/1.1 200 OK\r\nContent-Type: text/html\r\n\r\n<h1>Hello from Flynax!</h1><p>Native Backend Working!</p>"
    server_send(client, response)
    
    print("Response sent!")
