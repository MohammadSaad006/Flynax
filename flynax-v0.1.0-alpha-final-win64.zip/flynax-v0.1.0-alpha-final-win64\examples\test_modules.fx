import "examples/math.fx" as m

main():
    # Test namespaced function call
    int result = m.add(10, 20)
    print("Sum from module: ")
    print(result)

    # Test namespaced variable
    int p = m.pi
    print("PI from module: ")
    print(p)

    # Test local call in the same module (if we define one)
    localFunc()

localFunc():
    print("Called local function")
