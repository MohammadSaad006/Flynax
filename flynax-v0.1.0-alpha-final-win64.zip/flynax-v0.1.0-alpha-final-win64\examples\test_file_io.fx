# Real File I/O Test!

main:
    print("Writing to file...")
    file_write("hello.txt", "Hello from Flynax!")
    
    print("Reading from file...")
    let string content = file_read("hello.txt")
    
    print("File contains:")
    print(content)
    
    print("Success!")
