#pragma once

#include <memory>
#include <string>
#include <vector>

namespace flynax {

// Forward declarations
class ASTVisitor;

// Base AST Node
class ASTNode {
public:
  int line = 0;
  int column = 0;
  virtual ~ASTNode() = default;
  virtual void accept(ASTVisitor &visitor) = 0;
};

// Expression nodes
class Expression : public ASTNode {
public:
  virtual ~Expression() = default;
};

class IntegerLiteral : public Expression {
public:
  int value;
  explicit IntegerLiteral(int v) : value(v) {}
  void accept(ASTVisitor &visitor) override;
};

class FloatLiteral : public Expression {
public:
  double value;
  explicit FloatLiteral(double v) : value(v) {}
  void accept(ASTVisitor &visitor) override;
};

class StringLiteral : public Expression {
public:
  std::string value;
  explicit StringLiteral(const std::string &v) : value(v) {}
  void accept(ASTVisitor &visitor) override;
};

class Identifier : public Expression {
public:
  std::string name;
  explicit Identifier(const std::string &n) : name(n) {}
  void accept(ASTVisitor &visitor) override;
};

class BinaryOp : public Expression {
public:
  std::unique_ptr<Expression> left;
  std::string op;
  std::unique_ptr<Expression> right;

  BinaryOp(std::unique_ptr<Expression> l, const std::string &o,
           std::unique_ptr<Expression> r)
      : left(std::move(l)), op(o), right(std::move(r)) {}
  void accept(ASTVisitor &visitor) override;
};

class UnaryOp : public Expression {
public:
  std::string op;
  std::unique_ptr<Expression> right;

  UnaryOp(const std::string &o, std::unique_ptr<Expression> r)
      : op(o), right(std::move(r)) {}
  void accept(ASTVisitor &visitor) override;
};

class FunctionCall : public Expression {
public:
  std::string name;
  std::vector<std::unique_ptr<Expression>> args;

  FunctionCall(const std::string &n, std::vector<std::unique_ptr<Expression>> a)
      : name(n), args(std::move(a)) {}
  void accept(ASTVisitor &visitor) override;
};

class MemberAccess : public Expression {
public:
  std::unique_ptr<Expression> object;
  std::string member;
  bool isMethod;
  std::vector<std::unique_ptr<Expression>> args; // If it's a method call

  MemberAccess(std::unique_ptr<Expression> obj, const std::string &mem,
               bool method = false)
      : object(std::move(obj)), member(mem), isMethod(method) {}
  void accept(ASTVisitor &visitor) override;
};

class ArrayLiteral : public Expression {
public:
  std::vector<std::unique_ptr<Expression>> elements;

  ArrayLiteral(std::vector<std::unique_ptr<Expression>> elems)
      : elements(std::move(elems)) {}
  void accept(ASTVisitor &visitor) override;
};

class ArrayIndex : public Expression {
public:
  std::unique_ptr<Expression> array;
  std::unique_ptr<Expression> index;

  ArrayIndex(std::unique_ptr<Expression> arr, std::unique_ptr<Expression> idx)
      : array(std::move(arr)), index(std::move(idx)) {}
  void accept(ASTVisitor &visitor) override;
};

// Statement nodes
class Statement : public ASTNode {
public:
  virtual ~Statement() = default;
};

class ExpressionStatement : public Statement {
public:
  std::unique_ptr<Expression> expression;

  explicit ExpressionStatement(std::unique_ptr<Expression> expr)
      : expression(std::move(expr)) {}
  void accept(ASTVisitor &visitor) override;
};

class VariableDecl : public Statement {
public:
  std::string type;
  std::string name;
  std::unique_ptr<Expression> initializer;

  VariableDecl(const std::string &t, const std::string &n,
               std::unique_ptr<Expression> init)
      : type(t), name(n), initializer(std::move(init)) {}
  void accept(ASTVisitor &visitor) override;
};

class Assignment : public Statement {
public:
  std::unique_ptr<Expression> target;
  std::unique_ptr<Expression> value;

  Assignment(std::unique_ptr<Expression> t, std::unique_ptr<Expression> v)
      : target(std::move(t)), value(std::move(v)) {}
  void accept(ASTVisitor &visitor) override;
};

class FunctionDecl : public Statement {
public:
  std::string name;
  std::string returnType;
  std::vector<std::pair<std::string, std::string>> params; // (type, name)
  std::vector<std::unique_ptr<Statement>> body;

  FunctionDecl(const std::string &n, const std::string &rt = "void")
      : name(n), returnType(rt) {}
  void accept(ASTVisitor &visitor) override;
};

class ExternDecl : public Statement {
public:
  std::string name;
  std::string returnType;
  std::vector<std::pair<std::string, std::string>> params; // (type, name)

  ExternDecl(const std::string &n, const std::string &rt = "void")
      : name(n), returnType(rt) {}
  void accept(ASTVisitor &visitor) override;
};

class IfStatement : public Statement {
public:
  std::unique_ptr<Expression> condition;
  std::vector<std::unique_ptr<Statement>> thenBranch;
  std::vector<std::unique_ptr<Statement>> elseBranch;

  IfStatement(std::unique_ptr<Expression> cond,
              std::vector<std::unique_ptr<Statement>> thenB,
              std::vector<std::unique_ptr<Statement>> elseB = {})
      : condition(std::move(cond)), thenBranch(std::move(thenB)),
        elseBranch(std::move(elseB)) {}

  void accept(ASTVisitor &visitor) override;
};

class ReturnStatement : public Statement {
public:
  std::unique_ptr<Expression> value;

  explicit ReturnStatement(std::unique_ptr<Expression> v = nullptr)
      : value(std::move(v)) {}

  void accept(ASTVisitor &visitor) override;
};

class WhileStatement : public Statement {
public:
  std::unique_ptr<Expression> condition;
  std::vector<std::unique_ptr<Statement>> body;

  WhileStatement(std::unique_ptr<Expression> cond,
                 std::vector<std::unique_ptr<Statement>> b)
      : condition(std::move(cond)), body(std::move(b)) {}

  void accept(ASTVisitor &visitor) override;
};

class ClassDecl : public Statement {
public:
  std::string name;
  std::vector<std::pair<std::string, std::string>> fields; // (type, name)
  std::vector<std::unique_ptr<FunctionDecl>> methods;

  ClassDecl(const std::string &n) : name(n) {}
  void accept(ASTVisitor &visitor) override;
};

class TryCatchStatement : public Statement {
public:
  std::vector<std::unique_ptr<Statement>> tryBlock;
  std::string exceptionType;
  std::string exceptionVariable;
  std::vector<std::unique_ptr<Statement>> catchBlock;
  std::vector<std::unique_ptr<Statement>> finallyBlock;

  TryCatchStatement(std::vector<std::unique_ptr<Statement>> tryB,
                    const std::string &exType, const std::string &exVar,
                    std::vector<std::unique_ptr<Statement>> catchB,
                    std::vector<std::unique_ptr<Statement>> finallyB = {})
      : tryBlock(std::move(tryB)), exceptionType(exType),
        exceptionVariable(exVar), catchBlock(std::move(catchB)),
        finallyBlock(std::move(finallyB)) {}

  void accept(ASTVisitor &visitor) override;
};

class ThrowStatement : public Statement {
public:
  std::unique_ptr<Expression> expression;

  explicit ThrowStatement(std::unique_ptr<Expression> expr)
      : expression(std::move(expr)) {}

  void accept(ASTVisitor &visitor) override;
};

// Program (root node)
class Program : public ASTNode {
public:
  std::vector<std::unique_ptr<Statement>> statements;
  void accept(ASTVisitor &visitor) override;
};

// Visitor interface for traversing AST
class ASTVisitor {
public:
  virtual ~ASTVisitor() = default;

  virtual void visit(IntegerLiteral &node) = 0;
  virtual void visit(FloatLiteral &node) = 0;
  virtual void visit(StringLiteral &node) = 0;
  virtual void visit(Identifier &node) = 0;
  virtual void visit(BinaryOp &node) = 0;
  virtual void visit(UnaryOp &node) = 0;
  virtual void visit(MemberAccess &node) = 0;
  virtual void visit(FunctionCall &node) = 0;
  virtual void visit(ExpressionStatement &node) = 0;
  virtual void visit(VariableDecl &node) = 0;
  virtual void visit(Assignment &node) = 0;
  virtual void visit(IfStatement &node) = 0;
  virtual void visit(WhileStatement &node) = 0;
  virtual void visit(FunctionDecl &node) = 0;
  virtual void visit(ExternDecl &node) = 0;
  virtual void visit(ClassDecl &node) = 0;
  virtual void visit(ReturnStatement &node) = 0;
  virtual void visit(TryCatchStatement &node) = 0;
  virtual void visit(ThrowStatement &node) = 0;
  virtual void visit(ArrayLiteral &node) = 0;
  virtual void visit(ArrayIndex &node) = 0;
  virtual void visit(Program &node) = 0;
};

} // namespace flynax
