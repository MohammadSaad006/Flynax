# Flynax SQL Database Test

main:
    print("=== SQLite Integration Test ===")
    
    # Open database
    let db = sql_open("test.db")
    print("Database opened")
    
    # Create table
    sql_exec(db, "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, email TEXT)")
    print("Table created")
    
    # Insert data
    sql_exec(db, "INSERT INTO users (name, email) VALUES ('Alice', 'alice@example.com')")
    sql_exec(db, "INSERT INTO users (name, email) VALUES ('Bob', 'bob@example.com')")
    sql_exec(db, "INSERT INTO users (name, email) VALUES ('Charlie', 'charlie@example.com')")
    print("Data inserted")
    
    # Query data
    print("\n=== Query Results ===")
    let result = sql_query(db, "SELECT * FROM users")
    
    while (sql_next_row(result)):
        let int id = sql_get_int(result, 0)
        let string name = sql_get_string(result, 1)
        let string email = sql_get_string(result, 2)
        
        print("ID: ")
        print(id)
        print

("Name: " + name)
        print("Email: " + email)
        print("---")
    
    sql_free_result(result)
    
    # Test transactions
    print("\n=== Testing Transactions ===")
    sql_begin(db)
    sql_exec(db, "INSERT INTO users (name, email) VALUES ('David', 'david@example.com')")
    sql_rollback(db)
    print("Transaction rolled back")
    
    sql_begin(db)
    sql_exec(db, "INSERT INTO users (name, email) VALUES ('Eve', 'eve@example.com')")
    sql_commit(db)
    print("Transaction committed")
    
    # Close database
    sql_close(db)
    print("\n=== Test Complete ===")
