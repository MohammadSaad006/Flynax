# Exception handling demonstration in Flynax

main:
    print("Starting exception demo")
    
    # Try-catch example
    try:
        print("In try block")
        let int result = 10 / 2
        print("Result of division: ")
        print(result)
        
        # This would normally cause an error, but for now we just demonstrate syntax
        # throw("Division by zero error")  # This would be the actual exception
        
    catch(Error):
        print("An error occurred in catch block")
        print("Exception variable: ")
        print(ex)  # This would print the exception info
    
    print("After try-catch block")
    
    # Try-catch with finally example
    try:
        print("In second try block")
        let int x = 5
        let int y = 3
        let int z = x + y
        print("Sum is: ")
        print(z)
        
    catch(Error):
        print("Error in second try block")
        
    finally:
        print("Finally block always executes")
    
    print("Exception demo completed")