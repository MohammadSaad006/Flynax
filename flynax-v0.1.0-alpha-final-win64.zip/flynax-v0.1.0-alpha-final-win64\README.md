# Flynax Programming Language

**Flynax** is a modern compiled programming language that combines:
- ⚡ **C-like Performance** - Compiled to native code via LLVM
- 🚀 **C++ Features** - OOP, RAII, Smart Pointers, Generics (planned)
- 🐍 **Python-like Syntax** - Clean, minimal, easy to read

## Features

- **Clean Syntax**: No `def`, no `self`, auto-constructors
- **Strong Typing**: With type inference support
- **Memory Safety**: RAII and smart pointers (like modern C++)
- **Fast**: Compiles to optimized native code

## Syntax Example

```python
# Simple class with auto-constructor
class Point(int x, int y):
    
    move(int dx, int dy):
        x += dx
        y += dy

main:
    p = Point(10, 20)
    p.move(5, 5)
    print(f"Coordinates: {p.x}, {p.y}")
```

## Prerequisites

Before building Flynax, you need a **C++ compiler**:

- **Windows**: Install [Visual Studio Community](https://visualstudio.microsoft.com/downloads/) (free) with "Desktop development with C++"
- **Linux**: `sudo apt install build-essential` (Ubuntu/Debian) or `sudo yum groupinstall "Development Tools"` (RHEL/Fedora)  
- **macOS**: `xcode-select --install`

**Optional (for full performance)**: [LLVM](https://github.com/llvm/llvm-project/releases) - See [SETUP.md](SETUP.md) for detailed instructions.

## Building

### Quick Build (No CMake required)

**Windows (MSVC):**
```powershell
# Run from "Developer Command Prompt for VS"
build.bat
```

**Linux/macOS:**
```bash
chmod +x build.sh
./build.sh
```

### Alternative: CMake Build

```bash
mkdir build
cd build
cmake ..
cmake --build .
```

## Usage

```bash
flynax examples/hello.fx
```

## Project Structure

```
flynex/
├── include/          # Header files
│   ├── lexer.h      # Tokenizer
│   ├── parser.h     # Parser
│   └── ast.h        # Abstract Syntax Tree
├── src/             # Implementation
│   ├── main.cpp
│   ├── lexer.cpp
│   ├── parser.cpp
│   └── ast.cpp
├── examples/        # Example programs
└── CMakeLists.txt   # Build configuration
```

## Roadmap

- [x] Lexer with indentation support
- [x] Parser for basic syntax
- [ ] Semantic analysis
- [ ] LLVM IR code generation
- [ ] Standard library
- [ ] Generics/Templates
- [ ] Package manager

## License

MIT License

---

**Status**: Early Development (v0.1.0)
