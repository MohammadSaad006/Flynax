main:
    let win = sdl_init(800, 600, "Flynax Ultra Graphics Demo")
    ui_init(win)
    
    let t = 0
    let running = 1
    
    while (running == 1):
        running = sdl_poll_events(win)
        
        t = (t + 1)
        if (t > 100):
            t = 0
            
        # 1. Background Gradient (Beast Look)
        # Deep Purple to Dark Blue
        ui_panel_gradient(0, 0, 800, 600, 45, 10, 70, 15, 15, 40, 1)
        
        ui_begin_frame()

        # 2. Animated Header with "Back" Easing
        let header_ease = ui_ease_back(t)
        let h_t = (header_ease / 10)
        let header_y = ui_lerp(-100, 50, h_t)
        
        ui_panel_rounded(200, header_y, 400, 80, 20, 55, 55, 85, 220)
        ui_label(310, header_y + 25, "ULTRA ENGINE", 24, 0, 200, 255)
        
        # 3. Floating Card with Soft Glow Shadow
        let card_ease = ui_ease_in_out(t)
        let c_t = (card_ease / 10)
        let card_y = ui_lerp(200, 220, c_t)
        
        # Draw soft shadow (Glow)
        ui_shadow_soft(250, card_y, 300, 220, 25, 30, 100, 255, 150)
        
        # Rounded Card
        ui_panel_rounded(250, card_y, 300, 220, 15, 70, 70, 105, 255)
        ui_label(280, card_y + 30, "CSS-Level UI/UX", 20, 255, 255, 255)
        ui_label(280, card_y + 70, "• Gradients", 16, 200, 200, 220)
        ui_label(280, card_y + 100, "• Rounded Corners", 16, 200, 200, 220)
        ui_label(280, card_y + 130, "• Soft Shadows", 16, 200, 200, 220)
        
        # 4. Bouncing Button
        let bounce = ui_ease_bounce(t)
        let b_t = (bounce / 10)
        let btn_w = ui_lerp(120, 180, b_t)
        
        if (ui_button(400 - (btn_w / 2), card_y + 165, btn_w, 40, "BEAST!")):
            print("Power: UNLIMITED")
            
        ui_end_frame()
        sdl_present(win)
        sdl_delay(16)
        
    sdl_quit(win)
