# Full Stack Flynax App (Native Backend)
# Features: HTTP Server, JSON, Database (KV), Control Flow

main:
    # Initialize DB (create if not exists)
    let string db = "users.db"
    if (file_exists(db) == 0):
        print("Initializing database...")
        db_set(db, "admin", "secret")
        db_set(db, "guest", "welcome")
    
    # Start Server
    let int port = 3000
    let int server = server_init(port)
    print("Flynax Backend running on port 3000...")
    
    # Infinite Server Loop
    while (1):
        print("Waiting for request...")
        let int client = server_accept(server)
        
        # Read request
        let string req = server_read(client)
        print("Request received")
        
        # Create JSON Response
        let int json = json_new()
        json_add_str(json, "status", "ok")
        json_add_str(json, "server", "Flynax Native")
        
        # Read from DB and add to response
        let string admin_pass = db_get(db, "admin")
        json_add_str(json, "admin_pass", admin_pass)
        
        let string payload = json_dump(json)
        
        # Build HTTP Response
        let string header = "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\n\r\n"
        server_send(client, header)
        server_send(client, payload)
        
        print("Response sent")
