#pragma once

#include "ast.h"
#include <map>
#include <memory>
#include <stdexcept>
#include <string>

// Forward declare LLVM types to avoid including heavy headers
namespace llvm {
class LLVMContext;
class Module;
class Value;
class Function;
class Type;
template <typename T> class IRBuilder;
} // namespace llvm

namespace flynax {

// Custom exception for code generation errors with source mapping
class CodeGenError : public std::runtime_error {
public:
  int line;
  int column;
  CodeGenError(const std::string &message, int l, int c)
      : std::runtime_error(message), line(l), column(c) {}
};

// Code generator that converts AST to LLVM IR
class CodeGenerator : public ASTVisitor {
public:
  struct Impl; // PIMPL pattern to hide LLVM includes
  std::unique_ptr<Impl> impl_;

  CodeGenerator();
  ~CodeGenerator();

  // Generate code for the entire program
  void generate(Program &program);

  // Write LLVM IR to file (.ll)
  void writeIR(const std::string &filename);

  // Compile to object file or executable
  bool compile(const std::string &exeName, bool isWasmTarget = false);

  // Visitor implementations
  void visit(IntegerLiteral &node) override;
  void visit(FloatLiteral &node) override;
  void visit(StringLiteral &node) override;
  void visit(Identifier &node) override;
  void visit(BinaryOp &node) override;
  void visit(UnaryOp &node) override;
  void visit(MemberAccess &node) override;
  void visit(FunctionCall &node) override;

  void visit(ExpressionStatement &node) override;
  void visit(VariableDecl &node) override;
  void visit(Assignment &node) override;
  void visit(IfStatement &node) override;
  void visit(WhileStatement &node) override;
  void visit(TryCatchStatement &node) override;
  void visit(ThrowStatement &node) override;
  void visit(ArrayLiteral &node) override;
  void visit(ArrayIndex &node) override;
  void visit(FunctionDecl &node) override;
  void visit(ExternDecl &node) override;
  void visit(ClassDecl &node) override;
  virtual void visit(ReturnStatement &node) override;
  void visit(Program &node) override;

private:
  // Helper methods (will be defined in impl)
  void *createMainFunction();
  void *getOrCreatePrintFunction();
  void *convertType(const std::string &typeName);
};

} // namespace flynax
